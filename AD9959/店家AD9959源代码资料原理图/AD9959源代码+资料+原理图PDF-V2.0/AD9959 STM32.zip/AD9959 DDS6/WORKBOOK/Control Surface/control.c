#include "control.h"
#include "keyfour.h"
#include "ui.h"
#include "lcd.h"
#include "AD9959.H"
#include <ctype.h>

uint32_t  pointFrequency=20000000;       //��ƵƵ��
u32 SweepMinFre = 1000000;
u32 SweepMaxFre = 40000000;
u32 SweepStepFre = 100000;
u16 SweepTime = 200;//ms
u8  SweepFlag = 0;

void pointFrefunction(void)
{
	char key_value;
	uint8_t j=0,flag=0,flag1=0,value=0;
	uint32_t sumvalue=0;
	pointFreUI();
	
	while(1)
	{
    key_value=Read_KeyValue();
		if(key_value)
		{
			if(key_value=='S')
			{
				if((!flag))
				{
					 flag=1;
					 LCD_ShowString(280,45+30*2,16*3,16,16,"   ");
					 LCD_ShowString(280,45+30,16*3,16,16,"<--");
				}
				else if(flag==1)
				{
					 LCD_ShowString(280,45+30,16*3,16,16,"   ");
					 LCD_ShowString(280,45+30*2,16*3,16,16,"<--");
					 flag=2;
				}
			}
			else if((key_value=='E')&&(flag==1))
			{
				flag1=1;
				LCD_ShowString(90,45+30,16*8,16,16,"        ");
			}
			else if((key_value=='E')&&(flag==2))
			{
					  /*��Ƶ���*/	
				Write_frequence(0,pointFrequency);//�������ܣ�����ͨ�����Ƶ��
				Write_frequence(1,pointFrequency);
				return;
			}
			else if((isalnum(key_value))&&flag1&&(j<8))
			{
				value=key_value-'0';
				LCD_ShowNum(10+16*5+8*j,45+30,value,1,16);//(90,75)
				sumvalue=sumvalue*10+value;
				pointFrequency=sumvalue;
				j++;
			}
		}
	}
	
}

void sweepFrefunction(void)
{
	char key_value;
	uint8_t i=0,flag=0,flag1=0,value=0;
	uint32_t sumvalue=0,sumvalue1=0,sumvalue2=0;
	sweepFreUI();
	
	while(1)
	{
    key_value=Read_KeyValue();
		if(key_value)
		{
			if(key_value=='S')
			{
				if(!flag)
				{
					 flag=1;
					 LCD_ShowString(280,45+30,16*3,16,16,"<--");
				}
				else if(flag==1)
				{
					 LCD_ShowString(280,45+30,16*3,16,16,"   ");
					 LCD_ShowString(280,45+30*2,16*3,16,16,"<--");
					 flag=2;
				}
				else if(flag==2)
				{
					 LCD_ShowString(280,45+30*2,16*3,16,16,"   ");
					 LCD_ShowString(280,45+30*3,16*3,16,16,"<--");
					 flag=3;
				}
				else if(flag==3)
				{
					 LCD_ShowString(280,45+30*3,16*3,16,16,"   ");
					 LCD_ShowString(280,45+30*4,16*3,16,16,"<--");
					 flag=4;
				}
			}
			
			else if((key_value=='E')&&(flag==1))
			{
				i=0;
				flag1=1;
				LCD_ShowString(90,45+30,16*8,16,16,"        ");
			}
			else if((key_value=='E')&&(flag==2))
			{
				i=0;
				flag1=2;
				LCD_ShowString(90,45+30*2,16*8,16,16,"        ");
			}
			else if((key_value=='E')&&(flag==3))
			{
				i=0;
				flag1=3;
				LCD_ShowString(90,45+30*3,16*8,16,16,"        ");
			}
			else if((key_value=='E')&&(flag==4))
			{
					  /*��Ƶ���*/	
				Write_frequence(0,SweepMinFre);//�������ܣ�����ͨ�����Ƶ��
				Write_frequence(1,SweepMinFre);
				SweepFlag=1;
				return;
			}
			else if((isalnum(key_value))&&(flag1==1)&&(i<8)&&(flag==1))
			{
				value=key_value-'0';
				LCD_ShowNum(10+16*5+8*i,45+30,value,1,16);//(90,75)
				sumvalue=sumvalue*10+value;
				SweepMaxFre=sumvalue;
				i++;
			}
			else if((isalnum(key_value))&&(flag1==2)&&(i<8)&&(flag==2))
			{
				value=key_value-'0';
				LCD_ShowNum(10+16*5+8*i,45+30*2,value,1,16);//(90,75)
				sumvalue1=sumvalue*10+value;
				SweepMinFre=sumvalue1;
				i++;
			}
			else if((isalnum(key_value))&&(flag1==3)&&(i<8)&&(flag==3))
			{
				value=key_value-'0';
				LCD_ShowNum(10+16*5+8*i,45+30*3,value,1,16);//(90,75)
				sumvalue2=sumvalue*10+value;
				SweepStepFre=sumvalue2;
				i++;
			}
		}
	}
	
}

void pointFremeasurefunction(void)
{
  pointFremeasureUI();
}

void sweepFremeasurefunction(void)
{
  sweepFremeasureUI();
}

void functionSwitch(void)
{
	char t;
	t=Read_KeyValue();
	switch(t)
	{
		case 'A':
			pointFrefunction();
			break;
		case 'B':
			sweepFrefunction();
			break;
		case 'C':
			pointFremeasurefunction();
			break;
		case 'D':
			sweepFremeasurefunction();
			break;
	}
}



