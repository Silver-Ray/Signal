#ifndef __CONTROL_H
#define __CONTROL_H

void pointFrefunction(void);
void sweepFrefunction(void);
void pointFremeasurefunction(void);
void sweepFremeasurefunction(void);
void functionSwitch(void);

#endif
