#ifndef __KEYFOUR_H
#define __KEYFOUR_H
#include "sys.h"

void KeyBoard_Init(void);
u8 Read_KeyValue(void);

#endif
