/**
  ******************************************************************************
  * @file    keyfour.c
  * @author   
  * @version V1.0
  * @date    2017-03-10
  * @email   wh199727@163.com
  ******************************************************************************
  */
	/*******************************************************************************
                         �����б�
//4*4keys PF0-PF7                        

	   
******************************************************************************/
#include "stm32f10x.h"
#include "keyfour.h"
#include "delay.h"
#include "lcd.h"

void KeyBoard_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF,ENABLE);//ʹ��PORTEʱ��
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOF, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(GPIOF, &GPIO_InitStructure);
	GPIO_SetBits(GPIOF, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3);
	GPIO_ResetBits(GPIOF, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
}
/*------------------------------??????--------------------------------------------* ??: ??????,?????
* ??:
* ??: ?
* ??: ?????????
* ????????0
--------------------------------------------------------------------------------------*/
u8 Read_KeyValue(void)
{
u8 KeyValue=0;
if((GPIO_ReadInputData(GPIOF)&0xff)!=0x0f)
{
delay_ms(10);
if((GPIO_ReadInputData(GPIOF)&0xff)!=0x0f)
{
GPIO_SetBits(GPIOF, GPIO_Pin_0);
GPIO_ResetBits(GPIOF, GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3);
switch(GPIO_ReadInputData(GPIOF)&0xff)
{
case 0x11: KeyValue = '1'; break;
case 0x21: KeyValue = '4'; break;
case 0x41: KeyValue = '7'; break;
case 0x81: KeyValue = 'S';break;
}
GPIO_SetBits(GPIOF, GPIO_Pin_1);
GPIO_ResetBits(GPIOF, GPIO_Pin_0 | GPIO_Pin_2 | GPIO_Pin_3);
switch(GPIO_ReadInputData(GPIOF)&0xff)
{
case 0x12: KeyValue = '2'; break;
case 0x22: KeyValue = '6'; break;
case 0x42: KeyValue = '8';break;
case 0x82: KeyValue = '0';break;
}
GPIO_SetBits(GPIOF, GPIO_Pin_2);
GPIO_ResetBits(GPIOF, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_3);
switch(GPIO_ReadInputData(GPIOF)&0xff)
{
case 0x14: KeyValue = '3'; break;
case 0x24: KeyValue = '6'; break;
case 0x44: KeyValue = '9';break;
case 0x84: KeyValue = 'E';break;
}
GPIO_SetBits(GPIOF, GPIO_Pin_3);
GPIO_ResetBits(GPIOF, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2);
switch(GPIO_ReadInputData(GPIOF)&0xff)
{
case 0x18: KeyValue = 'A'; break;
case 0x28: KeyValue = 'B'; break;
case 0x48: KeyValue = 'C';break;
case 0x88: KeyValue = 'D';break;
}
GPIO_SetBits(GPIOF, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3);
GPIO_ResetBits(GPIOF, GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 |
GPIO_Pin_7);
while((GPIO_ReadInputData(GPIOF)&0xff)!=0x0f);
return KeyValue;
}
}
return 0;
}

/*--------------------------------THE END--------------------------------------------*/

