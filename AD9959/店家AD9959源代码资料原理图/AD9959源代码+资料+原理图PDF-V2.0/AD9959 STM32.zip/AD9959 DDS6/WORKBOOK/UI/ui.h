#ifndef __UI_H
#define __UI_H

void memberUI(void);
void boundaryUI(void);
void pointFreUI(void);
void sweepFreUI(void);
void pointFremeasureUI(void);
void sweepFremeasureUI(void);

#endif
